// static/js/neo-inputs.js
(function () {
  const SELECTOR = `
    input[type="text"],
    input[type="email"],
    input[type="url"],
    input[type="search"],
    input[type="tel"],
    input[type="number"],
    input[type="password"],
    textarea,
    select
  `;

  // Wrap a node with .nm-wrap and move the node inside
  function wrapNeumorph(el) {
    // Skip if already wrapped
    if (el.parentElement && el.parentElement.classList.contains('nm-wrap')) return;

    const wrap = document.createElement('div');
    wrap.className = 'nm-wrap';

    // Size variants (optional via data-size="sm|lg")
    const size = el.getAttribute('data-size');
    if (size === 'sm') wrap.classList.add('nm-sm');
    if (size === 'lg') wrap.classList.add('nm-lg');

    // Textarea mode
    if (el.tagName === 'TEXTAREA') wrap.classList.add('nm-textarea');

    // Insert wrapper and move input inside
    el.parentNode.insertBefore(wrap, el);
    wrap.appendChild(el);

    // Addons for password inputs
    if (el.type === 'password') {
      const addon = document.createElement('div');
      addon.className = 'nm-addon';
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'nm-btn-icon';
      btn.setAttribute('aria-label', 'Show/Hide password');
      btn.innerHTML = '&#128065;'; // eye
      btn.addEventListener('click', () => {
        const show = el.type === 'password';
        el.type = show ? 'text' : 'password';
        btn.setAttribute('aria-pressed', String(show));
      });
      addon.appendChild(btn);
      wrap.appendChild(addon);
      wrap.classList.add('has-addon');
    }

    // Basic required validation on blur if data-required is set
    if (el.hasAttribute('data-required')) {
      el.addEventListener('blur', () => {
        const ok = !!String(el.value || '').trim();
        wrap.classList.toggle('is-valid', ok);
        wrap.classList.toggle('is-invalid', !ok);
      });
    }

    // Clear invalid state on input
    el.addEventListener('input', () => {
      wrap.classList.remove('is-invalid', 'nm-shake');
    });

    return wrap;
  }

  function enhance(container) {
    const targets = container.querySelectorAll(SELECTOR);
    targets.forEach(el => wrapNeumorph(el));
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Enhance any container marked with .nm-auto
    document.querySelectorAll('.nm-auto').forEach(enhance);

    // Optional: instant validation on submit for forms with data-validate="instant"
    document.querySelectorAll('form[data-validate="instant"]').forEach(form => {
      form.addEventListener('submit', (e) => {
        let ok = true;
        form.querySelectorAll('[data-required]').forEach(input => {
          const wrap = input.closest('.nm-wrap');
          const good = !!String(input.value || '').trim();
          wrap.classList.toggle('is-valid', good);
          wrap.classList.toggle('is-invalid', !good);
          if (!good) {
            wrap.classList.add('nm-shake');
            ok = false;
          }
        });
        if (!ok) e.preventDefault();
      });
    });
  });
})();
