// Auto Neumorphism for inputs inside any .nm-auto container
(function () {
  const SELECTOR = `
    input[type="text"],
    input[type="email"],
    input[type="url"],
    input[type="search"],
    input[type="tel"],
    input[type="number"],
    input[type="password"],
    textarea,
    select
  `;

  function wrap(el) {
    if (el.parentElement && el.parentElement.classList.contains('nm-wrap')) return;

    const w = document.createElement('div');
    w.className = 'nm-wrap';
    if (el.tagName === 'TEXTAREA') w.classList.add('nm-textarea');

    el.parentNode.insertBefore(w, el);
    w.appendChild(el);

    // (Optional) Right-side addon example:
    if (el.type === 'password') {
      const addon = document.createElement('div');
      addon.className = 'nm-addon';
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'nm-btn-icon';
      btn.setAttribute('aria-label', 'Show/Hide password');
      btn.innerHTML = '&#128065;'; // eye
      btn.addEventListener('click', () => {
        const show = el.type === 'password';
        el.type = show ? 'text' : 'password';
        btn.setAttribute('aria-pressed', String(show));
      });
      addon.appendChild(btn);
      w.appendChild(addon);
      w.classList.add('has-addon');
    }

    // Required blur validation (opt-in with data-required)
    if (el.hasAttribute('data-required')) {
      el.addEventListener('blur', () => {
        const ok = !!String(el.value || '').trim();
        w.classList.toggle('is-valid', ok);
        w.classList.toggle('is-invalid', !ok);
      });
    }

    el.addEventListener('input', () => {
      w.classList.remove('is-invalid', 'nm-shake');
    });
  }

  function enhance(root) {
    root.querySelectorAll(SELECTOR).forEach(wrap);
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nm-auto').forEach(enhance);

    // Instant validation for forms with data-validate="instant"
    document.querySelectorAll('form[data-validate="instant"]').forEach(form => {
      form.addEventListener('submit', (e) => {
        let ok = true;
        form.querySelectorAll('[data-required]').forEach(input => {
          const w = input.closest('.nm-wrap');
          const good = !!String(input.value || '').trim();
          w.classList.toggle('is-valid', good);
          w.classList.toggle('is-invalid', !good);
          if (!good) { w.classList.add('nm-shake'); ok = false; }
        });
        if (!ok) e.preventDefault();
      });
    });
  });
})();
